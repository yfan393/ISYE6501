# Akash Dey Sarkar (asarkar87@gatech.edu) - 904022460 
# Shivam Choudhary (schoudhary82@gatech.edu - 904050872 
# Vighnesh Madurai Srinivasan (vsrinivasan80@gatech.edu) - 904026550 
# Arvind Ram (aram43@gatech.edu) – 904049803 

library(kknn)
#Set your current woking directory
setwd('/Users/arvindram/Desktop/Gatech/Fall_2024/ISYE_6501/hw2/data 3.1/')
data = read.table('credit_card_data-headers.txt',header=TRUE) 

set.seed(110)

k_fold <- 10

data_shuffled <- data[sample(nrow(data)),]
folds <- cut(seq(1, nrow(data_shuffled)), breaks = k_fold, labels = FALSE)
folded_data <- list()
for(i in 1:k_fold){
  folded_data[[i]] <- data_shuffled[folds == i, ]
}

k_values <- 1:20
mean_accuracies <- numeric(length(k_values))

for (k_val in k_values) {
accuracies <- numeric(k_fold)
  for (i in 1:k_fold) {
    # Create training and test sets
    test_set <- folded_data[[i]]
    train_set <- do.call(rbind, folded_data[-i])
    model <- kknn(R1 ~ ., train_set,test_set, k=k_val, scale = TRUE)
    pred <- fitted(model)
    pred <- ifelse(pred > 0.5, 1, 0)
    accuracies[i] <- sum(pred == test_set$R1) / nrow(test_set)
    print(paste("For fold: ",i,"   Accuracy = ",accuracies[i]))
  }
mean_accuracies[k_val] <- mean(accuracies)
  print(paste("Mean accuracy across all folds for k_hyperparameter ",k_val," : ", round(mean_accuracies[k_val] * 100, 2), "%"))
}

best_k <- k_values[which.max(mean_accuracies)]
best_accuracy <- max(mean_accuracies)

print(paste("Best k value for KNN:", best_k, "\n"))
print(paste("Best mean accuracy:", round(best_accuracy * 100, 2)))