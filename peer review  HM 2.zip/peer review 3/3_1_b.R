# Akash Dey Sarkar (asarkar87@gatech.edu) - 904022460 
# Shivam Choudhary (schoudhary82@gatech.edu - 904050872 
# Vighnesh Madurai Srinivasan (vsrinivasan80@gatech.edu) - 904026550 
# Arvind Ram (aram43@gatech.edu) – 904049803 

library(kknn)


#Set your current woking directory
setwd('C:\\Users\\akash\\OneDrive\\Documents\\GT Coursework\\Intro to Analytics Modelling\\Homeworks\\HW2\\Data')
data = read.table('credit_card_data-headers.txt',header=TRUE)


# Set seed for reproducibility
set.seed(123)

n <- nrow(data)

# Defining the split ratio
train_ratio <- 0.6  
test_ratio <- 0.2    
validation_ratio <- 0.2

#Getting random indices
train_indices <- sample(1:n, size = train_ratio * n)
remaining_indices <- setdiff(1:n, train_indices)
test_indices <- sample(remaining_indices, size = test_ratio * n)
validation_indices <- setdiff(remaining_indices, test_indices)

# Splitting the data
train_data <- data[train_indices, ]
test_data <- data[test_indices, ]
validation_data <- data[validation_indices, ]


best_k <- NULL
best_acc <- 0
curr_acc <- 0

for (k in 1:20){
  model <- kknn(R1 ~ ., train_data,validation_data, k=k, scale = TRUE)
  #Predict current point
  pred <- fitted(model)
  #Round to 1 if predicted value>0.5
  rounded_pred <- ifelse(pred > 0.5, 1, 0)
  curr_acc <- sum(rounded_pred == validation_data$R1) / nrow(validation_data)
  print(paste("K = ",k,", Accuracy = ",curr_acc))
  if(curr_acc>best_acc){
    best_acc <- curr_acc
    best_k <- k
  }
}
# run best model on test data
model <- kknn(R1 ~ ., train_data, test_data, k=best_k, scale = TRUE)
pred_test <- fitted(model)
rounded_pred_test <- ifelse(pred_test > 0.5, 1, 0)
acc_test <- sum(rounded_pred_test == test_data$R1) / nrow(test_data)


print(paste("On test data, for K = ",best_k,", Accuracy = ",acc_test))