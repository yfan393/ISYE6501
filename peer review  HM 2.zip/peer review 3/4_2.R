# Akash Dey Sarkar (asarkar87@gatech.edu) - 904022460 
# Shivam Choudhary (schoudhary82@gatech.edu - 904050872 
# Vighnesh Madurai Srinivasan (vsrinivasan80@gatech.edu) - 904026550 
# Arvind Ram (aram43@gatech.edu) – 904049803

setwd('C:/Users/shiva/OneDrive/Desktop/MS_Analytics_GeorgiaTech/Semester-1/ISYE-6501-Analytics_Modeling/hw2/data_4.2')
data = read.table('iris.txt',header=TRUE)

data2 = data[,-c(1,2,5)] ### dropping sepal length and sepal width and also the class labels
df <- scale(data2)
wssvals <- c()
kvals <- c()
for (k in 2:10){
  km <- kmeans(df, k, nstart=25)
  wss <- km$tot.withinss
  print(typeof(wss))
  wssvals <- append(wssvals, wss)
  kvals <- append(kvals, k)
}
dfwss <- data.frame(kvals=kvals, wssvals=wssvals)
library(ggplot2)
plot <- ggplot(dfwss, mapping= aes(x = kvals, y = wssvals))+geom_point()+geom_line()+labs(title = "Elbow Plot with Petal Length and Petal Width",x = "number of clusters", y = "Within Cluster Sum of squares")
print(plot)

# ### using k=3 run clustering code - Taking only petal width and petal length
km <- kmeans(df, 3, nstart=25)
data$Cluster <- km$cluster

# ### clusteriub
ggplot(data, aes(x = Petal.Length, y = Petal.Width, color = as.factor(Cluster))) +
  geom_point(size = 3) +
  labs(title = "K-means Clustering of Flower Data",
       x = "Petal Length",
       y = "Petal Width",
       color = "Cluster")

### Cross tab of Cluster and Species to compute accuracy
table(data$Cluster, data$Species)