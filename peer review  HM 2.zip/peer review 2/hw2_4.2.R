library(here)
iris <- read.table(here("data 4.2", "iris.txt"), header = TRUE)

iris_data <- iris[, -5]
k <- 3

set.seed(123)
model <- kmeans(iris_data, centers = k, nstart = 15)
model

iris$cluster <- as.factor(model$cluster)
contingency_table <- table(iris$cluster, iris$Species)
contingency_table