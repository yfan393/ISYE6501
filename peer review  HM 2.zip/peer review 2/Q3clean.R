library(kknn)
library(caret)

dir()
data <- read.table("data 3.1/credit_card_data.txt", stringsAsFactors = FALSE, header = FALSE)
head(data)

#find maximum and mean accuracy using k fold number i.
accuracy1 = function(X){
  max_accur <- rep(0,X)
  mean_accur <- rep(0,X)
  for (i in 3:X){
    set.seed(123)
    # the number of K is set to be i
    train.kfold <- trainControl(method = "cv", number = i)
    
    ### Training
    data$V11 <- as.factor(data$V11)
    model.kfold <- train(V11 ~V1+V2+V3+V4+V5+V6+V7+V8+V9+V10,
                         data = data,
                         method = "kknn",
                         trControl = train.kfold)
    max_accur[i] = max(model.kfold$results$Accuracy)
    mean_accur[i] = mean(model.kfold$results$Accuracy)}
  #return(max_accur)
  return(mean_accur)
}

accuracy1(10)

#models
set.seed(123)

train.kfold1 <- trainControl(method = "cv", number = 9)

### Training
data$V11 <- as.factor(data$V11)
model.kfold1 <- train(V11 ~V1+V2+V3+V4+V5+V6+V7+V8+V9+V10,
                      data = data,
                      method = "kknn",
                      trControl = train.kfold1)
max(model.kfold1$results$Accuracy)
mean(model.kfold1$results$Accuracy)

print(model.kfold1)



set.seed(123)
# proportion for training + validation: 0.8
train_validation_proportion <- 0.8
num_folds <- 9  # Number of folds for cross-validation

# split the data: Random
shuffled_data <- data[sample(nrow(data)), ]
train_validation_size <- round(nrow(shuffled_data) * train_validation_proportion)

# Split into training + validation and test sets
train_validation_data <- shuffled_data[1:train_validation_size, ]
test_data <- shuffled_data[(train_validation_size + 1):nrow(shuffled_data), ]

# folds for cross-validation
folds <- cut(seq(1, nrow(train_validation_data)), breaks = num_folds, labels = FALSE)

accuracies <- c()
# k-fold cross-validation
for (i in 1:num_folds) {
  validation_indices <- which(folds == i, arr.ind = TRUE)
  validation_set <- train_validation_data[validation_indices, ]
  training_set <- train_validation_data[-validation_indices, ]
  knn_fit <- kknn(V11 ~ ., training_set, validation_set, k = 12, scale = TRUE)
  validation_predictions <- fitted(knn_fit)
  
  # Calculate accuracy
  accuracy <- sum(validation_predictions == validation_set$V11) / nrow(validation_set)
  accuracies <- c(accuracies, accuracy)  # Store the accuracy
}

# Calculate the mean accuracy across all folds
mean_accuracy <- mean(accuracies)
print(paste("Mean Cross-Validation Accuracy:", mean_accuracy))

# train on the entire training + validation set and test on the test set
final_knn_fit <- kknn(V11 ~ ., train_validation_data, test_data, k = 12, scale = TRUE)
final_test_predictions <- fitted(final_knn_fit)

# Calculate the accuracy on the test set
test_accuracy <- sum(final_test_predictions == test_data$V11) / nrow(test_data)
print(paste("Test Set Accuracy:", test_accuracy))

